# Couple Chef (Godot 4.3, Android, 2-player LAN co-op)

An original cooking-rush game *inspired by* the genre (not a copy of any commercial game).

## Play
1. Both phones on the same WiFi or one phone's hotspot.
2. Player 1: **Host Game** -> read the IP shown on screen.
3. Player 2: type that IP -> **Join Game**.
4. Controls (hybrid): drag on empty floor = joystick. Tap a station = auto-walk + use it.
   Grab ingredients, cook on grill/oven/steamer, tap SERVE with a matching plate. BIN clears your hands.

## Build APK on GitHub (no local setup)
1. Create a repo, push this folder.
2. Actions tab -> "Build Android APK" runs automatically -> download `CoupleChef-apk` artifact.
3. Unzip, install the APK on both phones (allow unknown sources).
Local alternative: open in Godot 4.3, install Android export templates, Project > Export > Android.

## Features in v0.1
Shared coins + stage progression | 3 restaurants (unlock with coins) | equipment & seating upgrades |
3 recipes per restaurant unlocking by stage | customers get less patient each stage | chef hat colors | save file.

## Next milestones
- M2: more chef outfits/faces, sounds, real sprites, order bubbles per customer
- M3: more stations (chopping, drinks), burnt food, special challenge stages
- M4: reconnect, host discovery (no typing IP), 3-4 players
