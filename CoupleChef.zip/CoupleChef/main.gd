extends Node2D
# Couple Chef - 2-player LAN co-op cooking prototype (Godot 4.3)
# Host-authoritative: the host simulates, the client sends position + actions.

const PORT := 7777
var HATS := [Color("e53935"), Color("1e88e5"), Color("43a047"), Color("fdd835"), Color("8e24aa")]
var HAT_NAMES := ["Red", "Blue", "Green", "Yellow", "Purple"]

var RESTAURANTS := {
    "Burger Bay": {"cost": 0, "col": Color("ffb74d"),
        "stations": [
            {"id": "bun", "k": "src", "item": "bun", "c": Color("d7a86e")},
            {"id": "raw", "k": "src", "item": "raw", "c": Color("c2185b")},
            {"id": "grill", "k": "cook", "inp": "raw", "out": "patty", "t": 4.0, "c": Color("616161")},
            {"id": "lettuce", "k": "src", "item": "lettuce", "c": Color("66bb6a")},
            {"id": "cheese", "k": "src", "item": "cheese", "c": Color("ffee58")},
            {"id": "serve", "k": "serve", "c": Color("90caf9")},
            {"id": "bin", "k": "bin", "c": Color("9e9e9e")}],
        "recipes": [
            {"n": "Burger", "i": ["bun", "patty"], "pr": 20, "lvl": 1},
            {"n": "Salad Burger", "i": ["bun", "patty", "lettuce"], "pr": 30, "lvl": 2},
            {"n": "Cheeseburger", "i": ["bun", "patty", "cheese"], "pr": 32, "lvl": 3}]},
    "Pizza Palace": {"cost": 600, "col": Color("ef9a9a"),
        "stations": [
            {"id": "dough", "k": "src", "item": "dough", "c": Color("f5e6c8")},
            {"id": "oven", "k": "cook", "inp": "dough", "out": "pizza", "t": 5.0, "c": Color("8d6e63")},
            {"id": "cheese", "k": "src", "item": "cheese", "c": Color("ffee58")},
            {"id": "basil", "k": "src", "item": "basil", "c": Color("388e3c")},
            {"id": "serve", "k": "serve", "c": Color("90caf9")},
            {"id": "bin", "k": "bin", "c": Color("9e9e9e")}],
        "recipes": [
            {"n": "Pizza", "i": ["pizza"], "pr": 25, "lvl": 1},
            {"n": "Cheesy Pizza", "i": ["pizza", "cheese"], "pr": 35, "lvl": 2},
            {"n": "Supreme", "i": ["pizza", "cheese", "basil"], "pr": 48, "lvl": 3}]},
    "Sushi Spot": {"cost": 1500, "col": Color("80deea"),
        "stations": [
            {"id": "rice", "k": "src", "item": "rice", "c": Color("fafafa")},
            {"id": "steamer", "k": "cook", "inp": "rice", "out": "sushirice", "t": 4.0, "c": Color("90a4ae")},
            {"id": "fish", "k": "src", "item": "fish", "c": Color("ff8a65")},
            {"id": "nori", "k": "src", "item": "nori", "c": Color("263238")},
            {"id": "serve", "k": "serve", "c": Color("90caf9")},
            {"id": "bin", "k": "bin", "c": Color("9e9e9e")}],
        "recipes": [
            {"n": "Rice Bowl", "i": ["sushirice"], "pr": 22, "lvl": 1},
            {"n": "Nigiri", "i": ["sushirice", "fish"], "pr": 40, "lvl": 2},
            {"n": "Maki Roll", "i": ["sushirice", "fish", "nori"], "pr": 55, "lvl": 3}]}
}

var st := {"coins": 0, "stage": 1, "rest": "Burger Bay", "unlocked": ["Burger Bay"],
    "grill": 0, "pat": 0, "phase": "shop", "time": 0.0, "score": 0,
    "orders": [], "stn": {}, "pl": {}, "msg": ""}

var playing := false
var is_host := false
var online := false
var my_id := 1
var pos := Vector2(640, 520)
var outfit := 0
var target_sid := ""
var joy_id := -1
var joy_origin := Vector2.ZERO
var joy_vec := Vector2.ZERO
var spawn_t := 2.0
var sync_t := 0.0
var ui_t := 0.0
var msg_t := 0.0
var net_ready := false

var menu: VBoxContainer
var shop: HBoxContainer
var status: Label
var ip_edit: LineEdit
var b_start: Button
var b_grill: Button
var b_pat: Button
var b_rest: Button
var b_outfit: Button

# ---------------------------------------------------------------- setup / UI
func _ready() -> void:
    var cl := CanvasLayer.new()
    add_child(cl)
    var root := Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    cl.add_child(root)

    menu = VBoxContainer.new()
    menu.position = Vector2(380, 120)
    menu.custom_minimum_size = Vector2(520, 0)
    menu.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(menu)
    var title := Label.new()
    title.text = "COUPLE CHEF"
    title.add_theme_font_size_override("font_size", 56)
    menu.add_child(title)
    status = Label.new()
    status.text = "Your WiFi IP: " + local_ip()
    status.add_theme_font_size_override("font_size", 26)
    menu.add_child(status)
    mk(menu, "Host Game", host_game)
    ip_edit = LineEdit.new()
    ip_edit.placeholder_text = "Partner's IP (e.g. 192.168.1.5)"
    ip_edit.add_theme_font_size_override("font_size", 26)
    ip_edit.custom_minimum_size = Vector2(0, 60)
    menu.add_child(ip_edit)
    mk(menu, "Join Game", join_game)
    mk(menu, "Solo Practice", solo_game)

    shop = HBoxContainer.new()
    shop.position = Vector2(20, 625)
    shop.mouse_filter = Control.MOUSE_FILTER_IGNORE
    shop.hide()
    root.add_child(shop)
    b_start = mk(shop, "Start", func(): req("start", ""))
    b_grill = mk(shop, "Grill", func(): req("grill", ""))
    b_pat = mk(shop, "Patience", func(): req("pat", ""))
    b_rest = mk(shop, "Restaurant", func():
        var nx := next_rest()
        req("rest" if st.unlocked.has(nx) else "unlock", nx))
    b_outfit = mk(shop, "Outfit", func():
        outfit = (outfit + 1) % HATS.size()
        refresh_ui())
    for b in [b_start, b_grill, b_pat, b_rest, b_outfit]:
        b.custom_minimum_size = Vector2(235, 80)
        b.add_theme_font_size_override("font_size", 22)

func mk(parent: Node, text: String, cb: Callable) -> Button:
    var b := Button.new()
    b.text = text
    b.add_theme_font_size_override("font_size", 28)
    b.custom_minimum_size = Vector2(0, 70)
    b.pressed.connect(cb)
    parent.add_child(b)
    return b

func local_ip() -> String:
    for a in IP.get_local_addresses():
        if a.begins_with("192.168.") or a.begins_with("10.") or a.begins_with("172."):
            return a
    return "unknown"

func next_rest() -> String:
    var names: Array = RESTAURANTS.keys()
    return names[(names.find(st.rest) + 1) % names.size()]

func refresh_ui() -> void:
    if shop == null:
        return
    shop.visible = playing and st.phase == "shop"
    b_start.text = "Start Shift\nGoal %d" % target()
    b_grill.text = "Equipment Lv%d\n%dc" % [st.grill, 100 * (st.grill + 1)]
    b_pat.text = "Cozy Seats Lv%d\n%dc" % [st.pat, 100 * (st.pat + 1)]
    var nx := next_rest()
    if st.unlocked.has(nx):
        b_rest.text = "Go to\n" + nx
    else:
        b_rest.text = "Unlock %s\n%dc" % [nx, RESTAURANTS[nx].cost]
    b_outfit.text = "Chef Outfit:\n" + HAT_NAMES[outfit]

# ---------------------------------------------------------------- networking
func setup_net() -> void:
    if net_ready:
        return
    net_ready = true
    multiplayer.peer_connected.connect(func(id):
        if is_host:
            st.pl[id] = new_player())
    multiplayer.peer_disconnected.connect(func(id):
        if is_host:
            st.pl.erase(id))
    multiplayer.connected_to_server.connect(begin)
    multiplayer.connection_failed.connect(func(): status.text = "Could not connect. Same WiFi?")
    multiplayer.server_disconnected.connect(func():
        playing = false
        menu.show()
        refresh_ui()
        status.text = "Disconnected from host")

func host_game() -> void:
    var peer := ENetMultiplayerPeer.new()
    if peer.create_server(PORT, 2) != OK:
        status.text = "Could not host"
        return
    multiplayer.multiplayer_peer = peer
    setup_net()
    is_host = true
    online = true
    begin()

func join_game() -> void:
    var peer := ENetMultiplayerPeer.new()
    if peer.create_client(ip_edit.text.strip_edges(), PORT) != OK:
        status.text = "Bad IP"
        return
    multiplayer.multiplayer_peer = peer
    setup_net()
    is_host = false
    online = true
    status.text = "Connecting..."

func solo_game() -> void:
    is_host = true
    online = false
    begin()

func begin() -> void:
    my_id = multiplayer.get_unique_id() if online else 1
    if is_host:
        load_save()
        st.pl[1] = new_player()
        init_stations()
    playing = true
    menu.hide()
    refresh_ui()

func new_player() -> Dictionary:
    return {"pos": Vector2(640, 520), "hold": [], "oc": 0}

@rpc("any_peer", "call_remote", "reliable")
func _act_rpc(a: String, arg: String) -> void:
    if is_host:
        _act(multiplayer.get_remote_sender_id(), a, arg)

@rpc("any_peer", "call_remote", "unreliable_ordered")
func _pos_rpc(p: Vector2, oc: int) -> void:
    var id := multiplayer.get_remote_sender_id()
    if is_host and st.pl.has(id):
        st.pl[id].pos = p
        st.pl[id].oc = oc

@rpc("authority", "call_remote", "unreliable_ordered")
func _sync_rpc(d: Dictionary) -> void:
    st = d

func req(a: String, arg: String) -> void:
    if is_host:
        _act(1, a, arg)
    else:
        _act_rpc.rpc_id(1, a, arg)

# ---------------------------------------------------------------- host logic
func stations() -> Array:
    var arr: Array = []
    var src: Array = RESTAURANTS[st.rest].stations
    var n := src.size()
    for i in n:
        var s: Dictionary = src[i].duplicate()
        s["pos"] = Vector2(110 + i * (1060.0 / (n - 1)), 300)
        arr.append(s)
    return arr

func find_station(sid: String) -> Dictionary:
    for s in stations():
        if s.id == sid:
            return s
    return {}

func station_at(p: Vector2) -> String:
    for s in stations():
        if p.distance_to(s.pos) < 65:
            return s.id
    return ""

func init_stations() -> void:
    st.stn = {}
    for s in stations():
        if s.k == "cook":
            st.stn[s.id] = {"s": 0, "t": 0.0}

func target() -> int:
    return st.stage * 80

func say(s: String) -> void:
    st.msg = s
    msg_t = 3.0

func buy(key: String, cost: int) -> void:
    if st.phase == "shop" and st.coins >= cost and st[key] < 5:
        st.coins -= cost
        st[key] += 1

func _act(id: int, a: String, arg: String) -> void:
    match a:
        "start":
            if st.phase == "shop":
                st.phase = "play"
                st.time = 90.0
                st.score = 0
                st.orders = []
                spawn_t = 2.0
                init_stations()
                say("Shift started!")
        "grill":
            buy("grill", 100 * (st.grill + 1))
        "pat":
            buy("pat", 100 * (st.pat + 1))
        "unlock":
            var c: int = RESTAURANTS[arg].cost
            if not st.unlocked.has(arg) and st.coins >= c and st.phase == "shop":
                st.coins -= c
                st.unlocked.append(arg)
                st.rest = arg
                init_stations()
        "rest":
            if st.unlocked.has(arg) and st.phase == "shop":
                st.rest = arg
                init_stations()
        "interact":
            _interact(id, arg)
    if a != "interact":
        save()

func _interact(id: int, sid: String) -> void:
    if st.phase != "play" or not st.pl.has(id):
        return
    var s := find_station(sid)
    var p: Dictionary = st.pl[id]
    if s.is_empty() or p.pos.distance_to(s.pos) > 170:
        return
    var hold: Array = p.hold
    match s.k:
        "src":
            if hold.size() < 3:
                hold.append(s.item)
        "cook":
            var c: Dictionary = st.stn[sid]
            if c.s == 0 and hold.has(s.inp):
                hold.erase(s.inp)
                c.s = 1
                c.t = 0.0
            elif c.s == 2 and hold.size() < 3:
                hold.append(s.out)
                c.s = 0
        "serve":
            serve(p)
        "bin":
            hold.clear()

func serve(p: Dictionary) -> void:
    var h: Array = p.hold.duplicate()
    h.sort()
    var best := -1
    for idx in st.orders.size():
        var need: Array = st.orders[idx].i.duplicate()
        need.sort()
        if need == h and (best == -1 or st.orders[idx].p < st.orders[best].p):
            best = idx
    if best == -1:
        return
    var o: Dictionary = st.orders[best]
    var gain: int = o.pr + int(o.p / o.pm * 10.0)
    st.coins += gain
    st.score += gain
    st.orders.remove_at(best)
    p.hold.clear()
    say("+%d coins!" % gain)

func sim(delta: float) -> void:
    for sid in st.stn:
        var c: Dictionary = st.stn[sid]
        if c.s == 1:
            c.t += delta * (1.0 + 0.25 * st.grill)
            if c.t >= find_station(sid).t:
                c.s = 2
    if msg_t > 0:
        msg_t -= delta
        if msg_t <= 0:
            st.msg = ""
    if st.phase != "play":
        return
    st.time -= delta
    spawn_t -= delta
    if spawn_t <= 0 and st.orders.size() < 5:
        var opts: Array = RESTAURANTS[st.rest].recipes.filter(func(r): return r.lvl <= st.stage)
        var r: Dictionary = opts.pick_random()
        var pm: float = max(16.0, 45.0 + st.pat * 8.0 - st.stage * 3.0)
        st.orders.append({"n": r.n, "i": r.i, "pr": r.pr, "p": pm, "pm": pm})
        spawn_t = max(2.5, 8.0 - st.stage * 0.6)
    for o in st.orders:
        o.p -= delta
    var before := st.orders.size()
    st.orders = st.orders.filter(func(o): return o.p > 0)
    if st.orders.size() < before:
        st.score = max(0, st.score - 5)
        say("A customer left angry!")
    if st.time <= 0:
        st.phase = "shop"
        if st.score >= target():
            st.stage += 1
            st.coins += 50 * st.stage
            say("Stage cleared! Bonus coins!")
        else:
            say("Missed the goal - try again!")
        st.orders = []
        for p in st.pl.values():
            p.hold = []
        save()

func save() -> void:
    var c := ConfigFile.new()
    for k in ["coins", "stage", "rest", "unlocked", "grill", "pat"]:
        c.set_value("s", k, st[k])
    c.save("user://save.cfg")

func load_save() -> void:
    var c := ConfigFile.new()
    if c.load("user://save.cfg") == OK:
        for k in ["coins", "stage", "rest", "unlocked", "grill", "pat"]:
            st[k] = c.get_value("s", k, st[k])

# ---------------------------------------------------------------- per-frame
func _process(delta: float) -> void:
    if not playing:
        return
    var dir := joy_vec
    if dir.length() < 0.1:
        dir = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
    if dir.length() > 0.1:
        target_sid = ""
    elif target_sid != "":
        var s := find_station(target_sid)
        if s.is_empty():
            target_sid = ""
        elif pos.distance_to(s.pos) < 130:
            req("interact", target_sid)
            target_sid = ""
        else:
            dir = (s.pos + Vector2(0, 100) - pos).normalized()
    pos += dir * 380.0 * delta
    pos = pos.clamp(Vector2(40, 400), Vector2(1240, 680))

    if is_host:
        st.pl[1].pos = pos
        st.pl[1].oc = outfit
        sim(delta)
        sync_t += delta
        if sync_t > 0.066:
            sync_t = 0.0
            if online and multiplayer.get_peers().size() > 0:
                _sync_rpc.rpc(st)
    else:
        _pos_rpc.rpc_id(1, pos, outfit)
    ui_t += delta
    if ui_t > 0.2:
        ui_t = 0.0
        refresh_ui()
    queue_redraw()

func _unhandled_input(e: InputEvent) -> void:
    if not playing:
        return
    if e is InputEventScreenTouch:
        if e.pressed:
            var sid := station_at(e.position)
            if sid != "":
                target_sid = sid
            elif joy_id == -1:
                joy_id = e.index
                joy_origin = e.position
                joy_vec = Vector2.ZERO
        elif e.index == joy_id:
            joy_id = -1
            joy_vec = Vector2.ZERO
    elif e is InputEventScreenDrag and e.index == joy_id:
        joy_vec = ((e.position - joy_origin) / 70.0).limit_length(1.0)

# ---------------------------------------------------------------- drawing
func txt(p: Vector2, s: String, size: int = 22, col: Color = Color.WHITE, w: float = -1.0) -> void:
    var f := ThemeDB.fallback_font
    if w > 0:
        draw_string(f, p - Vector2(w / 2.0, 0), s, HORIZONTAL_ALIGNMENT_CENTER, w, size, col)
    else:
        draw_string(f, p, s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)

func _draw() -> void:
    draw_rect(Rect2(0, 0, 1280, 720), Color("2b2d42"))
    if not playing:
        return
    var R: Dictionary = RESTAURANTS[st.rest]
    draw_rect(Rect2(0, 150, 1280, 570), Color("cfd8dc"))
    draw_rect(Rect2(0, 235, 1280, 130), R.col.darkened(0.25))
    for s in stations():
        draw_rect(Rect2(s.pos - Vector2(55, 55), Vector2(110, 110)), s.c)
        txt(s.pos + Vector2(0, 80), s.id.to_upper(), 18, Color("263238"), 110)
        if s.k == "cook":
            var c: Dictionary = st.stn.get(s.id, {"s": 0, "t": 0.0})
            var label := "READY" if c.s == 2 else ("%d%%" % int(c.t / s.t * 100.0) if c.s == 1 else "")
            txt(s.pos + Vector2(0, 8), label, 24, Color.WHITE, 110)
    # orders
    for i in st.orders.size():
        var o: Dictionary = st.orders[i]
        var x := 12 + i * 252
        draw_rect(Rect2(x, 10, 240, 120), Color("fff8e1"))
        txt(Vector2(x + 120, 38), o.n, 24, Color("263238"), 230)
        txt(Vector2(x + 120, 66), ", ".join(o.i), 17, Color("455a64"), 230)
        var f: float = clamp(o.p / o.pm, 0.0, 1.0)
        draw_rect(Rect2(x + 10, 98, 220, 14), Color("b0bec5"))
        draw_rect(Rect2(x + 10, 98, 220 * f, 14), Color.GREEN.lerp(Color.RED, 1.0 - f))
    # HUD
    var t := "Coins %d  |  Stage %d  |  %s" % [st.coins, st.stage, st.rest]
    if st.phase == "play":
        t += "  |  Time %d  |  Score %d/%d" % [int(st.time), st.score, target()]
    txt(Vector2(14, 175), t, 26, Color("263238"))
    if st.msg != "":
        txt(Vector2(640, 215), st.msg, 30, Color("d81b60"), 800)
    if st.phase == "shop":
        txt(Vector2(640, 590), "Upgrade, switch restaurants, pick outfits, then Start Shift", 24, Color("263238"), 1000)
    # players
    for id in st.pl:
        var p: Dictionary = st.pl[id]
        var pp: Vector2 = pos if id == my_id else p.pos
        var oc: int = outfit if id == my_id else p.oc
        draw_circle(pp, 28, Color("ffcc80"))
        draw_circle(pp + Vector2(0, -26), 17, HATS[oc % HATS.size()])
        if id == my_id:
            draw_arc(pp, 34, 0, TAU, 24, Color.WHITE, 3.0)
        txt(pp + Vector2(0, -52), ",".join(p.hold), 17, Color("263238"), 180)
    if joy_id != -1:
        draw_circle(joy_origin, 70, Color(1, 1, 1, 0.25))
        draw_circle(joy_origin + joy_vec * 70, 30, Color(1, 1, 1, 0.6))
